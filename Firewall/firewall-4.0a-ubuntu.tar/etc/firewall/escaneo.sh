#!/bin/bash

# Script para buscar IPs de determinados dominios
#
#Version 4.0a
#

#Cambio al directorio de trabajo
pushd $(dirname $0)

#Cargo la configuracion
source config.conf

#Verifico si existe el directorio permitidos
if [ ! -d $PERM_DIR ]; then

	# Creo el directorio permitidos
	mkdir $PERM_DIR

fi

#Verifico si existe el directorio permitidos por ip
if [ ! -d $PERM_DIR/$PROC_DIR ]; then

	# Creo el directorio permitidos
	mkdir $PERM_DIR/$PROC_DIR

fi

#Inicio regitro de log
echo $(date +%Y-%m-%d-%H:%M)" - Iniciando escaneo de dominios" >> $LOGE


# Verifico si existe algun archivo de dominios o ips pemitidas parra escanear
ls -1 $PERM_DIR/*.conf &> /dev/null

#Tomo la fecha y hora actual
TIMESTAMP=$(date +%Y%m%d%H%M)

#Seteo variable de retorno
RETORNO=0

#Elimino los permitidos que ya se borraron
for a in $(ls -1d $PERM_DIR/$PROC_DIR/*.conf 2> /dev/null); do

	#Verifico si exite el archivo .conf correspondiente
	ls $PERM_DIR/$(basename ${a}) > /dev/null

	if [ $? != 0 ]; then

		#Muestro mensaje sobre la eliminacion del directorio del dominio procesado
		echo $(date +%Y-%m-%d-%H:%M) - "Eliminando -> "${a}  >> $LOGE

		#Borro el direcorio obsoleto
		rm -rf ${a}

		#Seteo que se debe ejecutar el firewall
		RETORNO=1

	else

		#Recorro el contenido del directorio .conf
		for b in $(ls -1 ${a} 2> /dev/null); do

			#busco la definicion del directorio dentro del archivo de configuracion
			grep ${b} $PERM_DIR/$(basename ${a})

			if [ $? != 0 ]; then

				#elimino el archivo del dominio escaneado con las IPs
				rm -rf ${a}/${b}

				#Muestro mensaje sobre la eliminacion del archivo
				echo $(date +%Y-%m-%d-%H:%M) - "Eliminando -> "${a}/${b}  >> $LOGE

				#Seteo que se debe ejecutar el firewall
				RETORNO=1

			fi

		done

	fi

done

#Busco los archivos de configuracion
for a in $(ls -1 $PERM_DIR/*.conf 2> /dev/null); do

	#Muestro mensaje sobre el archivo de configuracion que se esta procesando
	echo $(date +%Y-%m-%d-%H:%M) - "Procesando -> "$( basename ${a} ) >> $LOGE

	#Armo nombre del directorio
	DOM_DIR=$(basename ${a})

	#Verifico si existe el directorio para el archivo .conf
	if [ ! -d $PERM_DIR/$PROC_DIR/${DOM_DIR} ]; then mkdir $PERM_DIR/$PROC_DIR/${DOM_DIR}; fi

	# Recorro el archivo .conf
	for i in $(cat ${a} | grep -v \#); do

		# Registro analizado
		echo $(date +%Y-%m-%d-%H:%M) - "   Dominio -> "${i} >> $LOGE

		#Determino si es un dominio o una IP o una red
		echo ${i} | grep -oE "([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})(/2[5-9]|/30)?$" > /dev/null
		if [ "$?" != "0" ]; then

			#Determino el rango de ips
			RANGO=$(host $i | grep address | grep -v IPv6 | cut -d\  -f4 )

			#Verifico si es un dominio valido
			if [ "$RANGO" = "" ]; then

				#Registro en el log
				echo $(date +%Y-%m-%d-%H:%M)" *        NO SE PUDO RESOLVER EL DOMINIO - ESTO PUEDE SER UN ERROR TEMPORAL"  >> $LOGE

			else

				#Verifico si esxiste el archivo de IPs del Dominio
				if [ ! -f $PERM_DIR/$PROC_DIR/${DOM_DIR}/${i} ]; then touch $PERM_DIR/$PROC_DIR/${DOM_DIR}/${i};fi

				# Recorro las direcciones obtenidas
				for j in $RANGO; do

					#Verifico si es una IP existente en cualquier dominio
					grep $j: $PERM_DIR/$PROC_DIR/${DOM_DIR}/* > /dev/null
					if [ $? != 0 ]; then

						#Agrego la IP nueva a la tabla
						echo $j:$TIMESTAMP >> $PERM_DIR/$PROC_DIR/${DOM_DIR}/${i}

						#Registro en el log
						echo $(date +%Y-%m-%d-%H:%M) -"       IP: "$j agregada al dominio: ${i} >> $LOGE

						## Se agrego una nueva IP
						RETORNO=1

					else

						#Actualizo su timestamp
						sed -i 's/'${j}':.*/'${j}'\:'${TIMESTAMP}'/g' $PERM_DIR/$PROC_DIR/${DOM_DIR}/${i} &> /dev/null

					fi

			 	done

			fi

		else

			#Verifico si es una IP existente en alguno de los dominios analizados
			grep $i: $PERM_DIR/$PROC_DIR/${DOM_DIR}/* > /dev/null
			if [ $? != 0 ]; then

				#Verifico si la IP ya fue procesada
				grep $i: $PERM_DIR/$PROC_DIR/${DOM_DIR}/.ip > /dev/null
				if [ $? != 0 ]; then

					#Agrego la IP nueva a la tabla
					echo $i:$TIMESTAMP >> $PERM_DIR/$PROC_DIR/${DOM_DIR}/.ip

					## Se agrego una nueva IP
					RETORNO=1

				fi

			else

				#Registro en el log
				echo $(date +%Y-%m-%d-%H:%M)" *        DIRECCION IP YA ANALIZADA LA MISMA SE DEBERIA BORRAR"  >> $LOGE

			fi

		fi

	done

done

#Elimino las entradas que tienen mas de un mes
EXPIREDATE=$( date --date=$EXPIRE" days ago" +%Y%m%d%H%M )

#Recorro los .conf en busca de dominios expirados
for a in $(ls -1 $PERM_DIR/*.conf 2> /dev/null); do

    #Armo nombre del directorio
	DOM_DIR=$( basename ${a} )

	#Proceso los dominios escaneados
	for n in $(ls -1 $PERM_DIR/$PROC_DIR/${DOM_DIR}/* 2> /dev/null ); do

		#Tomo la longitud del archivo
		SIZE=$(stat -c%s ${n})
		if [ $SIZE -lt 8 ]; then

			#Borro el archivo
			rm ${n}

		else

			#Bucle para eliminar las entradas viejas
			for j in $(cat ${n}); do

				#Tomo la fecha de actualizacion
				ACT_DATE=$(echo ${j} | cut -d\: -f2)

				#Verifico si la fecha de actualizacion esta vencida
				if [ $ACT_DATE -lt $EXPIREDATE ]; then

					#Tomo la ip
					IP=$(echo ${j} | cut -d\: -f1)

					#Elimino la entrada
					sed -i '/'${IP}':.*/d' ${n}

					#Registro en el log
					echo $(date +%Y-%m-%d-%H:%M)" * IP: $IP tiempo expirado en -> "$(basename ${n}) >> $LOGE

					## Se elimino una IP por expiracion
					RETORNO=1

				fi

			done

		fi

	done

done

#Verifico que ocurri� con el procesamiento
# 0 No se hizo nada
# 1 Hubo cambios en las IP
if [ $RETORNO = 1 ]; then

	#Ejecuto el firewall
	source firewall.sh

fi

popd