#!/bin/bash



#Scrip para aplicat el fitrado de paquetes

#

#Version 4.0

#



#Cambio al directorio de trabajo

pushd $(dirname $0)



#Cargo la configuracion

source config.conf



####################################################################

#

# Definici¢n de funciones

#

####################################################################



#Funcion que arma el listado de IPs y Redes para habilitar en el squid

function stop() {



	#Registro en el log

	echo $(date +%Y-%m-%d-%H:%M) - Firewall Detenido >> $LOG



	$IPTABLES -F

	$IPTABLES -F -t nat

	$IPTABLES -X

	$IPTABLES -X -t nat

	$IPTABLES -P INPUT ACCEPT

	$IPTABLES -P OUTPUT ACCEPT

	$IPTABLES -P FORWARD ACCEPT



}





#####################################################################

#####################################################################

#####################################################################



# Verifico la opci¢n de arranque pasada (start, stop, etc..)

case "$1" in



	stop)



		stop

		popd

		exit 0

		;;





	restart|reload)

		stop



esac



##--------------------------Comienzo Firewall---------------------------------##

#----Idedntificacion automatica de las interfaces-----#

echo $(date +%Y-%m-%d-%H:%M) - Detectando Interfaces >> $LOG



### Interface Externa:

echo "    Interface externa: $EXTIF"  >> $LOG



## Determino la IP externa

EXTIP="`ip addr show dev $EXTIF | grep global | cut -d/ -f1 | cut -d\  -f6`"

if [ "$EXTIP" = '' ]; then

	echo "        Cancelando...: No se puede deeterminar la direccion IP de $EXTIF !" >> $LOG

	popd

	exit 1

fi

echo "    IP externa: $EXTIP" >> $LOG



## Determino el gateway externo

EXTGW=$(ip r | grep default | cut -d\  -f3)

echo "    Gateway por defecto: $EXTGW" >> $LOG



### Interface interna:LAN

echo "    Interface interna: $INTIF" >> $LOG



## Determine internal IP

INTIP="`ip addr show dev $INTIF | grep global | cut -d/ -f1 | cut -d\  -f6`"

if [ "$INTIP" = '' ]; then

	echo "        Cancelando...: No se puede deeterminar la direccion IP de $INTIF !" >> $LOG

	popd

	exit 1

fi

echo "    IP interna: $INTIP" >> $LOG



## Determino la direccion de red de la red interna

INTLAN=$(ip route list scope link | grep "proto kernel" | grep $INTIF| cut -d\  -f1 )

echo "    RED interna: $INTLAN" >> $LOG



#Registro en el log

echo "" >> $LOG

echo $(date +%Y-%m-%d-%H:%M) - Iniciando Firewall >> $LOG



##Determino el puesto de redireccion para el trafico HTTP

REDIRECT_PORT=$SQUID_PORT



if [ $DANSGUARDIAN = "SI" ]; then

	REDIRECT_PORT=$DANS_PORT

fi





#----Reseteo y borro todas las cadenas que puedan estar definidas-----#



#Limpio todas las reglas/cadenas de IPTABLES



#Flush

$IPTABLES -F

$IPTABLES -F -t nat



#Delete

$IPTABLES -X

$IPTABLES -X -t nat



#----Creacion delas reglas-----#

echo $(date +%Y-%m-%d-%H:%M) - Implementando las reglas del firewall  >> $LOG





#######################

## Reglas de INPUT ##

#######################



# Verifico si el servidor es virtualizado

ping -c1 -w1 host.miescuela.local &> /dev/null



if [ $? = 0 ]; then



	#Bloqueo ssh si no viene del host.miescuela.local

	$IPTABLES -A INPUT -p tcp ! -s host.miescuela.local --dport 22 -j DROP



else



	#Bloqueo ssh si no viene del host.miescuela.local

	$IPTABLES -A INPUT -p tcp -s $INTLAN --dport 22 -j DROP



fi



###################

##POSTROUTING##

###################





# COLOCAR LAS REGLAS ESPECIFICAS A PARTIR DE ESTE LUGAR

#

#

#





#Nateo de una maquina espec¡fica

#Masquerade para maquinas de la red interna hacia Internet ( Cambiar IP_MAQUINA )

#	$IPTABLES -A POSTROUTING -t nat -s IP_MAQUINA -o $EXTIF -j MASQUERADE



#Nateo de puertos espec¡ficos

#Enmascaramiento para el puerto 25 (smtp)

#	$IPTABLES -A POSTROUTING -t nat -p tcp -s $INTLAN -o $EXTIF --dport 25 -j MASQUERADE



#Enmascaramiento para el puerto 110 (POP)

#	$IPTABLES -A POSTROUTING -t nat -p tcp -s $INTLAN -o $EXTIF --dport 110 -j MASQUERADE





#

#

#

# FIN REGLAS ESPECIFICAS





#Redirecciono el trafico http al PROXY o DANSGUARDIAN

$IPTABLES -A PREROUTING -t nat -p tcp -i $INTIF ! -d $INTIP --dport http -j REDIRECT --to $REDIRECT_PORT



# Redirijo los pedidos directos al proxy squid al DANSGUARDIAN. SI se encuentra definido DANSGUARDIAN="SI"

# Con esta regla evito que alguien desde la Red Interna saltee el control de contenidos. Por ejemplo

# Si alguien en la RED Interna configura el proxy en el browser saltearia el DANSGUARDIAN.

if [ $DANSGUARDIAN = "SI" ]; then



	$IPTABLES -A PREROUTING -t nat -p tcp -i $INTIF -d $INTIP --dport $SQUID_PORT -j REDIRECT --to $REDIRECT_PORT



fi



#Verifico si existe el directorio permitidos por ip

if [ ! -d $PERM_DIR/$PROC_DIR ]; then



	# Creo el directorio permitidos

	mkdir $PERM_DIR/$PROC_DIR



fi



# Habilitaci¢n de destinos espec¡ficos para trafico https. Si se encuentra definido el archivo "permitidos"

# Verifico si existe algun archivo de dominios o ips pemitidas

ls -1 $PERM_DIR/*.conf &> /dev/null



if [ $? = 0 ]; then



	#Optengo la cantidad de direcciones ip a preocesar

	CANTIP=0



	#Borro el archivo de ips definidos en los .conf

	echo "" > $PERM_DIR/$PROC_DIR/.ip



	#Verifico si esxiten archivos para procesar

	ls -1 $PERM_DIR/$PROC_DIR/* &> /dev/null

	if [ $? = 0 ]; then



		#Registro de log

		echo $(date +%Y-%m-%d-%H:%M) - Cargando IPs previamente calculadas  >> $LOG



		# Bucle para buscar los dominios permitidos

		for i in $(ls -1 $PERM_DIR/*.conf 2> /dev/null); do



			#Armo nombre del directorio

			DOM_DIR=$( basename ${i} )



			# Recorro las IP del dominio ya calculados

			for j in $( cat $PERM_DIR/$PROC_DIR/${DOM_DIR}/* 2> /dev/null | cut -d\: -f1); do



				#Cargo la regla de acceso

	 	 		$IPTABLES -A POSTROUTING -t nat -p tcp -s $INTLAN -o $EXTIF -d $j --dport 443 -j MASQUERADE



				#Incremento el contador

				let CANTIP=CANTIP+1



			done



		done



		#Registro de log

		echo $(date +%Y-%m-%d-%H:%M)" -      Cantidad de IPs habilitadas: " $CANTIP  >> $LOG



	fi





else



	#Mensaje de no hay dominios https habilitados

	echo $(date +%Y-%m-%d-%H:%M) - ATENCION no hay dominios HTTPS habilitados  >> $LOG

	echo "" >> $LOG

fi



popd

exit 0
